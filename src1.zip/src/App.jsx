import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { auth } from './firebase'; 
import { onAuthStateChanged } from "firebase/auth";
import Header from './components/Header'; 
import Footer from './components/Footer'; 
import Auth from './pages/Auth'; 
import Home from './pages/Home';
// baaki pages...

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div style={{height: '100vh', background: '#000428', display: 'flex', justifyContent: 'center', alignItems: 'center', color: '#00d2ff'}}>
        <h2>SYSTEM INITIALIZING...</h2>
      </div>
    );
  }

  return (
    <div className="App">
      {user && <Header />}
      <Routes>
        <Route path="/auth" element={!user ? <Auth onLogin={() => setUser(auth.currentUser)} /> : <Navigate to="/" />} />
        <Route path="/" element={user ? <Home /> : <Navigate to="/auth" />} />
        {/* Baaki routes bhi user ? <Page /> : <Navigate to="/auth" /> format mein rakhein */}
        <Route path="*" element={<Navigate to={user ? "/" : "/auth"} />} />
      </Routes>
      {user && <Footer />}
    </div>
  );
}
export default App;