import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { auth } from '../firebase'; 
import { signOut, onAuthStateChanged } from "firebase/auth";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
    faBug, faLock, faInfoCircle, faPhoneAlt, faFolderOpen, 
    faHome, faUserCheck, faBars, faTimes, faSignInAlt, faSignOutAlt, faCode 
} from '@fortawesome/free-solid-svg-icons';
import logoImage from '../assets/logo.jpg'; 

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setIsMenuOpen(false);
      navigate('/auth');
    } catch (error) {
      alert("Error: " + error.message);
    }
  };

  return (
    <>
      <style>
        {`
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { overflow-x: hidden; width: 100%; }

          .nav-list {
            display: flex;
            list-style: none;
            gap: 15px;
            margin: 0;
            padding: 0;
            align-items: center;
          }

          .hamburger {
            display: none;
            cursor: pointer;
            font-size: 24px;
            color: #2563EB;
            z-index: 1001;
          }

          @media (max-width: 992px) {
            .nav-list {
              display: ${isMenuOpen ? 'flex' : 'none'};
              flex-direction: column;
              position: absolute;
              top: 100%;
              left: 0;
              width: 100%;
              background: #ffffff;
              padding: 15px 0;
              box-shadow: 0 10px 20px rgba(0,0,0,0.1);
              z-index: 1000;
              border-top: 1px solid #f1f5f9;
            }
            .nav-list li { width: 100%; display: flex; justify-content: center; }
            .hamburger { display: block; }
            
            .nav-link-mobile {
                width: 90%;
                padding: 12px 15px !important;
                border-bottom: 1px solid #f8fafc;
                justify-content: flex-start !important;
            }
          }

          .dev-glow {
            animation: glow-pulse 2.5s infinite;
            border: 1px solid #2563EB !important;
          }
          @keyframes glow-pulse {
            0% { box-shadow: 0 0 0px rgba(37, 99, 235, 0.2); }
            50% { box-shadow: 0 0 10px rgba(37, 99, 235, 0.4); }
            100% { box-shadow: 0 0 0px rgba(37, 99, 235, 0.2); }
          }
        `}
      </style>

      <header style={styles.header}>
        <nav style={styles.navbar}>
          <div style={styles.logoGroup}>
            <Link to="/" style={styles.logoLink} onClick={() => setIsMenuOpen(false)}>
              <div style={styles.logoWrapper}>
                <img src={logoImage} alt="Logo" style={styles.logoImg} />
              </div>
              <div style={styles.brandText}>
                <h2 style={styles.mainTitle}>CSAM <span style={styles.accent}>PORTAL</span></h2>
                <span style={styles.subTitle}>By Ayan Ansari</span>
              </div>
            </Link>
          </div>

          <div className="hamburger" onClick={toggleMenu}>
            <FontAwesomeIcon icon={isMenuOpen ? faTimes : faBars} />
          </div>

          <ul className="nav-list">
            <li><Link to="/" className="nav-link-mobile" onClick={() => setIsMenuOpen(false)} style={styles.link}><FontAwesomeIcon icon={faHome} style={styles.icon}/> Home</Link></li>
            <li><Link to="/frauds" className="nav-link-mobile" onClick={() => setIsMenuOpen(false)} style={styles.link}><FontAwesomeIcon icon={faBug} style={styles.icon}/> Frauds</Link></li>
            <li><Link to="/safety" className="nav-link-mobile" onClick={() => setIsMenuOpen(false)} style={styles.link}><FontAwesomeIcon icon={faLock} style={styles.icon}/> Safety</Link></li>
            <li><Link to="/resources" className="nav-link-mobile" onClick={() => setIsMenuOpen(false)} style={styles.link}><FontAwesomeIcon icon={faFolderOpen} style={styles.icon}/> Resources</Link></li>
            <li><Link to="/contact" className="nav-link-mobile" onClick={() => setIsMenuOpen(false)} style={styles.link}><FontAwesomeIcon icon={faPhoneAlt} style={styles.icon}/> Contact</Link></li>

            <li>
              {user ? (
                <button onClick={handleLogout} style={styles.logoutBtn}>
                  <FontAwesomeIcon icon={faSignOutAlt} style={{marginRight: '8px'}} /> Logout
                </button>
              ) : (
                <Link to="/auth" onClick={() => setIsMenuOpen(false)} style={styles.authBtn}>
                  <FontAwesomeIcon icon={faSignInAlt} style={{marginRight: '8px'}} /> Login
                </Link>
              )}
            </li>
          </ul>

          <div className="dev-badge-desktop dev-glow" style={styles.devBadge}>
             <div style={styles.devBadgeInner}>
                <FontAwesomeIcon icon={faUserCheck} style={{color: '#3b82f6', marginRight: '6px'}} />
                <span>Dev: Ayan Ansari</span>
             </div>
          </div>
        </nav>
      </header>
    </>
  );
}

const styles = {
  header: { 
    position: 'sticky', 
    top: 0, 
    zIndex: 1000, 
    background: '#ffffff', 
    borderBottom: '1px solid #e2e8f0', 
    padding: '10px 15px',
    width: '100%' 
  },
  navbar: { 
    display: 'flex', 
    justifyContent: 'space-between', // Fixed hyphen issue
    alignItems: 'center', 
    maxWidth: '1200px', 
    margin: '0 auto' 
  },
  logoLink: { textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' },
  logoWrapper: { width: '38px', height: '38px', borderRadius: '50%', overflow: 'hidden', border: '2px solid #2563EB' },
  logoImg: { width: '100%', height: '100%', objectFit: 'cover' },
  brandText: { display: 'flex', flexDirection: 'column' },
  mainTitle: { margin: 0, fontSize: '16px', fontWeight: '800', color: '#0f172a' },
  accent: { color: '#2563EB' },
  subTitle: { fontSize: '9px', color: '#64748b', fontWeight: '600', textTransform: 'uppercase' },
  link: { textDecoration: 'none', color: '#334155', fontSize: '14px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 0', cursor: 'pointer' },
  icon: { color: '#2563EB', width: '16px' },
  authBtn: { textDecoration: 'none', background: '#2563EB', color: '#fff', padding: '8px 18px', borderRadius: '8px', fontSize: '14px', fontWeight: '700', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center' },
  logoutBtn: { background: '#dc2626', color: '#fff', padding: '8px 18px', borderRadius: '8px', fontSize: '14px', fontWeight: '700', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center' },
  devBadge: { background: '#0f172a', color: '#fff', padding: '7px 14px', borderRadius: '30px', fontSize: '10px', fontWeight: '700', display: 'flex', alignItems: 'center' },
  devBadgeInner: { display: 'flex', alignItems: 'center' }
};

export default Header;