import React, { useState, useEffect } from 'react';
import { auth, googleProvider } from '../firebase'; 
import { 
    signInWithEmailAndPassword, 
    createUserWithEmailAndPassword, 
    signOut, 
    signInWithPopup,
    signInWithRedirect,
    getRedirectResult,
    onAuthStateChanged,
    GoogleAuthProvider 
} from "firebase/auth";
import emailjs from '@emailjs/browser';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope, faLock, faMicrochip, faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import { faGoogle } from '@fortawesome/free-brands-svg-icons';
import logoImage from '../assets/logo.jpg';

const Auth = ({ onLogin }) => {
    const [isLogin, setIsLogin] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPass, setShowPass] = useState(false);
    const [otpSent, setOtpSent] = useState(false);
    const [userOtp, setUserOtp] = useState('');
    const [generatedOtp, setGeneratedOtp] = useState(null);
    const [loading, setLoading] = useState(false);
    const [timer, setTimer] = useState(0);

    // 1. MOBILE PE REDIRECT KE BAAD DATA CATCH KARNE KE LIYE
    useEffect(() => {
        const checkRedirect = async () => {
            try {
                const result = await getRedirectResult(auth);
                if (result?.user) {
                    console.log("Redirect Login Success");
                    onLogin(); 
                }
            } catch (error) {
                if (error.code !== 'auth/internal-error') {
                    console.error("Redirect Error:", error.message);
                }
            }
        };
        checkRedirect();
    }, [onLogin]);

    // 2. AUTO-LOGIN CHECK (Sabse Important: Mobile par wapas aane pe ye kaam karega)
    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            if (user) {
                onLogin(); // Agar user logged in hai toh dashboard bhej do
            }
        });
        return () => unsubscribe();
    }, [onLogin]);

    useEffect(() => {
        let interval;
        if (timer > 0) interval = setInterval(() => setTimer((prev) => prev - 1), 1000);
        return () => clearInterval(interval);
    }, [timer]);

    // Google Login - PC aur Mobile dono ke liye optimized
    const handleGoogleSignIn = async () => {
        setLoading(true);
        try {
            const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
            
            if (isMobile) {
                // Mobile browsers popup block kar dete hain isliye Redirect use kar rahe hain
                await signInWithRedirect(auth, googleProvider);
            } else {
                // PC par popup fast aur smooth hota hai
                const result = await signInWithPopup(auth, googleProvider);
                if (result.user) onLogin();
            }
        } catch (error) {
            alert("Error: " + error.message);
        } finally {
            setLoading(false);
        }
    };

    const handleAuth = async (e) => {
        e.preventDefault();
        try {
            setLoading(true);
            if (isLogin) {
                await signInWithEmailAndPassword(auth, email, password);
                onLogin();
            } else {
                if (!otpSent) {
                    const otp = Math.floor(100000 + Math.random() * 900000);
                    setGeneratedOtp(otp);
                    await emailjs.send('service_h9ztoke', 'template_6xl5bn5', { to_email: email, otp: otp }, '-biSy8oTgoepoKft7');
                    setOtpSent(true); setTimer(60);
                } else if (userOtp === generatedOtp?.toString()) {
                    await createUserWithEmailAndPassword(auth, email, password);
                    await signOut(auth);
                    alert("Account Created! Sign In now.");
                    setIsLogin(true); setOtpSent(false);
                } else { alert("Invalid OTP"); }
            }
        } catch (error) { alert(error.message); } finally { setLoading(false); }
    };

    return (
        <div className="auth-wrapper">
            <style>{`
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body, html { width: 100%; height: 100%; background: #030712; overflow: hidden; }
                .auth-wrapper { width: 100%; min-height: 100dvh; background: #030712; position: relative; }
                .auth-page { width: 100%; height: 100dvh; display: flex; align-items: center; justify-content: center; position: relative; padding: 15px; z-index: 5; }
                .aurora-bg { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; filter: blur(100px); opacity: 0.5; pointer-events: none; }
                .glow { position: absolute; border-radius: 50%; animation: drift 15s infinite alternate linear; }
                .glow-1 { width: 60vw; height: 60vw; background: #1d4ed8; top: -15%; left: -15%; }
                .glow-2 { width: 70vw; height: 70vw; background: #701a75; bottom: -15%; right: -15%; }
                @keyframes drift { from { transform: translate(0,0); } to { transform: translate(40px, 40px); } }
                .auth-card { z-index: 10; width: 100%; max-width: 400px; background: rgba(255,255,255,0.06); backdrop-filter: blur(25px); border: 1px solid rgba(255,255,255,0.12); border-radius: 30px; padding: 35px 25px; text-align: center; box-shadow: 0 25px 60px -12px rgba(0,0,0,0.8); }
                .auth-logo { width: 65px; height: 65px; border-radius: 18px; margin-bottom: 15px; border: 1.5px solid #3b82f6; object-fit: cover; }
                .form { display: flex; flex-direction: column; gap: 15px; }
                .input-field { position: relative; width: 100%; }
                .icon { position: absolute; left: 18px; top: 50%; transform: translateY(-50%); color: #3b82f6; font-size: 15px; }
                .toggle-eye { position: absolute; right: 18px; top: 50%; transform: translateY(-50%); color: #6b7280; cursor: pointer; padding: 5px; }
                .input-field input { width: 100%; padding: 14px 45px 14px 52px; background: rgba(0, 0, 0, 0.5); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 16px; color: #fff; font-size: 15px; outline: none; }
                .btn-main { padding: 15px; background: #3b82f6; color: white; border: none; border-radius: 16px; font-weight: 700; cursor: pointer; transition: 0.3s; }
                .or-divider { margin: 22px 0; color: #4b5563; font-size: 12px; position: relative; display: flex; align-items: center; justify-content: center; }
                .or-divider::before { content: ""; position: absolute; width: 100%; height: 1px; background: rgba(255,255,255,0.1); }
                .or-divider span { position: relative; background: #080b14; padding: 0 15px; }
                .btn-google { width: 100%; padding: 13px; background: #fff; color: #000; border: none; border-radius: 16px; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 12px; }
                .toggle-text { margin-top: 25px; color: #9ca3af; font-size: 14px; }
                .toggle-text span { color: #3b82f6; font-weight: 700; cursor: pointer; }
                .timer { position: absolute; right: 18px; top: 50%; transform: translateY(-50%); color: #10b981; font-size: 13px; font-weight: 700; }
            `}</style>

            <div className="auth-page">
                <div className="aurora-bg">
                    <div className="glow glow-1"></div>
                    <div className="glow glow-2"></div>
                </div>

                <div className="auth-card">
                    <img src={logoImage} alt="Logo" className="auth-logo" />
                    <h3 style={{color:'#fff'}}>{isLogin ? "Welcome Back" : "Join CSAM"}</h3>
                    <p style={{color:'#9ca3af', marginBottom:'25px'}}>CSAM Security (AyanCore)</p>

                    <form onSubmit={handleAuth} className="form">
                        {!otpSent ? (
                            <>
                                <div className="input-field">
                                    <FontAwesomeIcon icon={faEnvelope} className="icon" />
                                    <input type="email" placeholder="Email Address" onChange={(e) => setEmail(e.target.value)} required />
                                </div>
                                <div className="input-field">
                                    <FontAwesomeIcon icon={faLock} className="icon" />
                                    <input type={showPass ? "text" : "password"} placeholder="Password" onChange={(e) => setPassword(e.target.value)} required />
                                    <FontAwesomeIcon icon={showPass ? faEyeSlash : faEye} className="toggle-eye" onClick={() => setShowPass(!showPass)} />
                                </div>
                            </>
                        ) : (
                            <div className="input-field">
                                <FontAwesomeIcon icon={faMicrochip} className="icon" />
                                <input type="text" placeholder="Enter OTP" onChange={(e) => setUserOtp(e.target.value)} required />
                                {timer > 0 && <span className="timer">{timer}s</span>}
                            </div>
                        )}
                        <button type="submit" className="btn-main" disabled={loading}>
                            {loading ? "Verifying..." : (isLogin ? "Login" : (otpSent ? "Register" : "Send OTP"))}
                        </button>
                    </form>

                    <div className="or-divider"><span>OR</span></div>

                    <button type="button" onClick={handleGoogleSignIn} className="btn-google" disabled={loading}>
                        <FontAwesomeIcon icon={faGoogle} /> {loading ? "Connecting..." : "Continue with Google"}
                    </button>

                    <p className="toggle-text">
                        {isLogin ? "New user?" : "Have an account?"} 
                        <span onClick={() => {setIsLogin(!isLogin); setOtpSent(false);}}>
                            {isLogin ? " Register" : " Login"}
                        </span>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Auth;